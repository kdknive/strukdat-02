// Nama     : Kevin Dyandradiva
// NPM      : 140810180046
// Deskripsi: Program Bioskop
// Kelas    : B - 2018

#include <iostream>
#include <string.h>

using namespace std;

struct Theater
{
    int room;
    char seat[3];
    char movieTitle[50];
};

int main()
{
    Theater movie;
    movie.room = 7;
    strcpy(movie.seat, "J9");
    strcpy(movie.movieTitle, "Adit & Jarwo");

    cout << movie.movieTitle << endl;
    cout << movie.room << endl;
    cout << movie.seat << endl;
}
