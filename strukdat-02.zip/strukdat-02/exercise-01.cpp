// Nama     : Kevin Dyandradiva
// NPM      : 140810180046
// Deskripsi: Program Identitas Orang
// Kelas    : B - 2018

#include <iostream>
#include <string>

using namespace std;

struct Orang
{
    int umur;
    string nama;
    char jk;
    char goldar;
};

int main()
{
    Orang orang;

    orang.umur = 10;
    orang.nama = "Kevin Dyandradiva";
    orang.jk = 'L';
    orang.goldar = 'O';

    cout << orang.nama << endl;
    cout << orang.umur << endl;
    cout << orang.jk << endl;
    cout << orang.goldar << endl;
}

