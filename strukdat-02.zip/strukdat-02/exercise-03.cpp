// Nama     : Kevin Dyandradiva
// NPM      : 140810180046
// Deskripsi: Program Gaji
// Kelas    : B - 2018

#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

struct Worker
{
  string NIP;
  string name;
  int group;
  int salary;
};

class SelectionSort
{
private:
  template <typename T>
  void swapper(T& a, T& b)
  {
        T temp = a;
        a = b;
        b = temp;
  }

  void option(Worker worker[], string arr[], int N)
  {
        char opt;

        cout << "Sort By:\n"
             << "(1)Name\n(2)NIP\n(3)Salary\n\(4)Group\n";
        cin >> opt;

        switch (opt)
        {
            case '1':
                for (int i = 0; i < N; ++i)
                  {
                    arr[i] = worker[i].name;
                    int len = worker[i].name.length();

                    for (int j = 0; j < len; ++j)
                        if(arr[i][j] > 64 && arr[i][j] < 91)
                            arr[i][j] += 32;
                  }
                break;
            case '2':
                for (int i = 0; i < N; ++i)
                    arr[i] = worker[i].NIP;
                break;
            case '3':
                for (int i = 0; i < N; ++i)
                    arr[i] = to_string(worker[N-i-1].salary);
                break;
            case '4':
                for (int i = 0; i < N; ++i)
                    arr[i] = worker[i].group;
                break;
            default:
              cout << "Not a Valid option! No sorting applied.\n";
            }
        }

public:
  void sorter(Worker worker[], int N, bool opt)
  {
        int min;
        string arr[N];

        if (opt == true)
          {
            option(worker, arr, N);
          }
        else if (opt == false)
          {
            for (int i = 0; i < N; ++i)
              {
                arr[i] = to_string(worker[N-i-1].salary);
              }
          }

        for (int i = 0; i < N - 1; ++i)
          {
            min = i;
            for (int j = i + 1; j < N; ++j)
              {
                if (arr[j] < arr[min])
                  min = j;
              }
            swapper(arr[i], arr[min]);
            swapper(worker[i], worker[min]);
          }
      }
} sort;

Worker get_data(Worker worker)
{
      const int salaryList[] {2000000, 3000000, 5000000, 8000000};

      cin.ignore();
      cout << "Enter Name: ";
      getline(cin, worker.name);

      cout << "Enter NIP: ";
      getline(cin, worker.NIP);

      cout << "Enter Group(1/2/3/4): ";
      cin >> worker.group;

      cout << "\n";

      worker.salary = salaryList[worker.group - 1];

      return worker;
    }

    int mean_salary(Worker worker[], int n)
    {
      int sum {0}, mean;

      for(int i = 0; i < n; ++i)
        {
          sum += worker[i].salary;
        }

      mean = sum / n;

      return mean;
}

void search_salary(Worker worker[], int N)
{
    int query;
    cout << "Which Group [1/2/3/4]?: ";
    cin >> query;

    for (int i = 0; i < N; ++i)
    {
        if(worker[i].group == query)
            cout << setw(5) << i + 1
                 << setw(23) << worker[i].NIP
                 << setw(25) << worker[i].name
                 << setw(11) << worker[i].salary
                 << setw(7) << worker[i].group
                 << "\n";

    }
}

void print_data(Worker worker[], int N)
{
      sort.sorter(worker, N, true);

      cout << setw(5) << "No."
           << setw(23) << "NIP"
           << setw(25) << "Name"
           << setw(11) << "Salary"
           << setw(7) << "Group"
           << "\n\n";

      for (int i = 0; i < N; ++i)
        {
          cout << setw(5) << i + 1
               << setw(23) << worker[i].NIP
               << setw(25) << worker[i].name
               << setw(11) << worker[i].salary
               << setw(7) << worker[i].group
               << "\n";
        }

      cout << setw(53) << "Mean Salary: "
           << setw(11) << mean_salary(worker, N)
           << "\n";

      sort.sorter(worker, N, false);

      cout << "Highest salary are earned by:\n";
      for (int i = 0; i < N; ++i)
        {
          if (worker[i].salary == worker[0].salary)
            {
              cout << worker[i].name << "\n";
            }
        }
      cout << "Highest Salary: " << worker[0].salary << "\n\n";

      cout << "Lowest salary are earned by:\n";
      for (int i = 0; i < N; ++i)
        {
          if (worker[i].salary == worker[N-1].salary)
            {
              cout << worker[i].name << "\n";
            }
        }
      cout << "Lowest Salary: " << worker[N-1].salary << "\n";
}

int main()
{
      int dataSize;
      char search;

      cout << "Enter Number of Worker(s): ";
      cin >> dataSize;

      Worker worker[dataSize];

      for(int i = 0; i < dataSize; ++i)
        {
          worker[i] = get_data(worker[i]);
        }

      print_data(worker, dataSize);

      cout << "Search for salary group? [Y/N] :";
      cin >> search;

      if (search == 'Y' || search == 'y')
            search_salary(worker, dataSize);
}
